<?php

class eq2Quests
{
	var $eq2QuestTables = array("quests", "quest_details");
	var $eq2QuestTypes = array('None','Prereq','Reward');
	var $eq2QuestSubtypes = array('None','Experience','Faction','Item','Quest','Race','Class','AdvLevel','TSLevel','Coin','Selectable','MaxCoin','MaxAdvLevel','MaxTSLevel',
																'TSExperience');
	
	public function __construct() 
	{
		$this->quest_id = $_GET['id'] ?? NULL;
		if( $this->quest_id > 0 )
			$this->quest_name = $this->GetQuestName();
	}
	
	public function DeleteQuest() 
	{
		global $eq2;
		
		$eq2->SQLQuery = sprintf("DELETE FROM ".DEV_DB.".quest_details WHERE quest_id = %s", $this->quest_id);
		$eq2->RunQuery();
		
		$eq2->SQLQuery = sprintf("DELETE FROM ".DEV_DB.".quests WHERE quest_id = %s", $this->quest_id);
		$eq2->RunQuery();
		
		$eq2->DeleteLUAScript($_POST['script_path']);
	}
	
	public function GetCleanQuestScriptName()
	{
		// sanitize
		$var = preg_replace("/[^a-zA-Z0-9]+/", "", html_entity_decode($this->quest_name, ENT_QUOTES));
		return sprintf("%s.lua", $var);
	}
	
	public function GetOptionsQuestDetailTypes($selected = '') 
	{
		$ret = "";
		foreach($this->eq2QuestTypes as $type) 
			$ret .= sprintf("<option%s>%s</option>", ( $type == $selected ) ? " selected" : "", $type);
				
		return $ret;		
	}

	public function GetOptionsQuestDetailSubTypes($selected = '') 
	{
		$ret = "";
		foreach($this->eq2QuestSubtypes as $subtype) 
			$ret .= sprintf("<option%s>%s</option>", ( $subtype == $selected ) ? " selected" : "", $subtype);
				
		return $ret;		
	}

	public function GetQuestData()
	{
		global $eq2;
		
		$eq2->SQLQuery = sprintf("SELECT * FROM ".DEV_DB.".quests WHERE quest_id = %s", $this->quest_id);
		return $eq2->RunQuerySingle();
	}
	
	public function GetQuestDetails()
	{
		global $eq2;
		
		$eq2->SQLQuery = sprintf("SELECT * FROM ".DEV_DB.".quest_details WHERE quest_id = %s", $this->quest_id);
		return $eq2->RunQueryMulti();
	}
	
	public function GetQuestName()
	{
		global $eq2;
		
		$eq2->SQLQuery = sprintf("SELECT name FROM ".DEV_DB.".quests WHERE quest_id = %s", $this->quest_id);
		$data = $eq2->RunQuerySingle();
		return $data['name'];
	}
	
	public function GetQuestZoneOptions()
	{
		global $eq2;
		
		$eq2->SQLQuery = sprintf("SELECT DISTINCT zone FROM ".DEV_DB.".quests ORDER BY zone");
		$results = $eq2->RunQueryMulti();
		
		if( is_array($results) )
		{
			$ret = "";
			foreach($results as $data)
				$ret .= sprintf('<option value="quests.php?zone=%s"%s>%s</option>', $data['zone'], ( isset($_GET['zone']) && $_GET['zone'] == $data['zone'] ) ? " selected" : "", $data['zone']);
		} 
		
		return $ret;
	}
	
	public function GetQuestOptionsByZone()
	{
		global $eq2;

		$quest_zone = $_GET['zone'];
		
		$eq2->SQLQuery = sprintf("SELECT quest_id, name FROM ".DEV_DB.".quests WHERE zone = '%s' ORDER BY lua_script", $eq2->db->sql_escape($quest_zone));
		$results = $eq2->RunQueryMulti();
		
		$ret = "";
		if( is_array($results) )
		{
			foreach($results as $data)
				$ret .= sprintf('<option value="quests.php?zone=%s&id=%s&tab=register"%s>%s (%d)</option>', $quest_zone, $data['quest_id'], ( isset($_GET['id']) && $_GET['id'] == $data['quest_id'] ) ? " selected" : "", $data['name'], $data['quest_id']);
		} 
		
		return $ret;
	}
	
	public function GetQuestScriptName($id)
	{
		global $eq2;
		
		$eq2->SQLQuery = sprintf("SELECT lua_script FROM ".DEV_DB.".quests WHERE quest_id = %s", $id);	
		return $eq2->RunQuerySingle();
	}
	
	public function GetQuestsMatching()
	{
		global $eq2;
		
		if( strlen($_POST['txtSearch']) > 0 )
		{
			$search = $eq2->SQLEscape($_POST['txtSearch']);
			$eq2->SQLQuery = "SELECT * FROM ".DEV_DB.".quests WHERE quest_id = '".$search."' OR (name RLIKE '".$search."') OR (description RLIKE '".$search."') OR (type RLIKE '".$search."') OR (zone RLIKE '".$search."') OR (lua_script RLIKE '".$search."') ORDER BY name";
			return $eq2->RunQueryMulti();
		}
	}
	
	public function PrintOffsiteLinks()
	{
	}

	public function GetQuestRewardsDescription($id)
	{
		global $eq2;
		
		$eq2->SQLQuery = "SELECT name FROM ".DEV_DB.".items WHERE id = '".$id."' ";
		return $eq2->RunQuerySingle();
	}
	
}

?>