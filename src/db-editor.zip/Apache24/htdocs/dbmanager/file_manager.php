<?php 
include("header.php"); 
if( $eq2->mLev < 250 ) { print("Options Not Available Yet!"); exit; }
?>
<div id="sub-menu1"></div>
<?php

?>