ace.define("ace/snippets/jack",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "jack";

});
